class Loja{
  constructor(id, cnpj, razaoSocial, nomeFantasia, email, telefone, endereco){
    this.id = id;
    this.cnpj = cnpj;
    this.razaoSocial = razaoSocial;
    this.nomeFantasia = nomeFantasia;
    this.email = email;
    this.telefone = telefone;
    this.endereco = endereco;
  }
}

class Livro{
  constructor(id, )
}

Simple jQuery menu. 

License: MIT license.
